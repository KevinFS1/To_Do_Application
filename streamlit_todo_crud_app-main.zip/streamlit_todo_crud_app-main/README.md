# streamlit_todo_crud_app
Streamlit ToDo CRUD App

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io//Jcharis/streamlit_todo_crud_app/main/app.py)

#### TODO CRUD App
+ Create
+ Read
+ Update
+ Delete


